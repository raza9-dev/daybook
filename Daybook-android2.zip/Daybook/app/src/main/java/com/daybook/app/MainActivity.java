package com.daybook.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.database.Cursor;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import androidx.core.content.FileProvider;
import androidx.core.content.IntentCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.io.File;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {

    private static final int PICK_FILE = 42;
    private FrameLayout root;
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private WebView printView; // kept alive while the print/PDF screen is open
    private OnBackInvokedCallback backCallback;
    private boolean pageReady = false;
    private String pendingBackup = null; // a backup file opened from WhatsApp, Files, etc.
    private static final String BACKUP_DIR = Environment.DIRECTORY_DOWNLOADS + "/Daybook/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Android 15+ draws apps edge-to-edge. The root view is padded by the system bars
        // (and the keyboard), and its colour fills the area behind them.
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#EDF2EE"));
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#EDF2EE"));
        root.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars()
                    | WindowInsetsCompat.Type.displayCutout());
            Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            v.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
            return WindowInsetsCompat.CONSUMED;
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);   // this is where your entries are kept
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setTextZoom(100);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                deliverPendingBackup();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("file:///android_asset/")) return false;
                if (url.startsWith("tel:")) {
                    try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse(url))); }
                    catch (ActivityNotFoundException ignored) { }
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Daybook"), PICK_FILE);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        handleIncoming(getIntent());

        // Android 13+ back gesture (required behaviour when targeting Android 16).
        if (Build.VERSION.SDK_INT >= 33) {
            backCallback = this::handleBack;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCallback);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncoming(intent);
    }

    /** Someone tapped a Daybook backup file in WhatsApp, Telegram, Files… and chose Daybook. */
    private void handleIncoming(Intent intent) {
        if (intent == null) return;
        Uri uri = null;
        if (Intent.ACTION_VIEW.equals(intent.getAction())) {
            uri = intent.getData();
        } else if (Intent.ACTION_SEND.equals(intent.getAction())) {
            uri = IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri.class);
        }
        if (uri == null) return;
        final Uri src = uri;
        new Thread(() -> {
            String text = readText(src);
            runOnUiThread(() -> {
                if (text == null) {
                    Toast.makeText(this, "Couldn't open this file.", Toast.LENGTH_LONG).show();
                    return;
                }
                pendingBackup = text;
                deliverPendingBackup();
            });
        }).start();
    }

    private void deliverPendingBackup() {
        if (!pageReady || pendingBackup == null) return;
        String js = "window.daybookIncoming && window.daybookIncoming(" + JSONObject.quote(pendingBackup) + ")";
        pendingBackup = null;
        web.evaluateJavascript(js, null);
    }

    private String readText(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) return null;
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            byte[] b = new byte[16384];
            int n, total = 0;
            while ((n = in.read(b)) != -1) {
                total += n;
                if (total > 30 * 1024 * 1024) return null; // not a Daybook backup
                buf.write(b, 0, n);
            }
            return buf.toString("UTF-8");
        } catch (Exception e) {
            return null;
        }
    }

    /** Let the page close a dialog or go back to Today first; otherwise leave the app. */
    private void handleBack() {
        web.evaluateJavascript("window.daybookBack && window.daybookBack()", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        handleBack(); // Android 12 and older
    }

    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= 33 && backCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);
        }
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PICK_FILE && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(result);
            fileCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private class Bridge {
        /** Share a backup or CSV through WhatsApp, Drive, email, etc. */
        @JavascriptInterface
        public void shareFile(String fileName, String mime, String content) {
            runOnUiThread(() -> {
                try {
                    File dir = new File(getCacheDir(), "backups");
                    dir.mkdirs();
                    File f = new File(dir, fileName.replaceAll("[^A-Za-z0-9._-]", "_"));
                    try (FileOutputStream out = new FileOutputStream(f)) {
                        out.write(content.getBytes(StandardCharsets.UTF_8));
                    }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this,
                            getPackageName() + ".files", f);
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType(mime);
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.putExtra(Intent.EXTRA_SUBJECT, fileName);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send, fileName));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Couldn't share the file: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            });
        }

        /** Save a backup into Downloads/Daybook (Android 10+). Returns "ok", "error" or "unsupported". */
        @JavascriptInterface
        public String saveBackup(String name, String json) {
            if (Build.VERSION.SDK_INT < 29) return "unsupported";
            try {
                ContentResolver cr = getContentResolver();
                Uri col = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                Uri target = null;
                try (Cursor c = cr.query(col, new String[]{MediaStore.Downloads._ID},
                        MediaStore.Downloads.DISPLAY_NAME + "=? AND " + MediaStore.Downloads.RELATIVE_PATH + "=?",
                        new String[]{name, BACKUP_DIR}, null)) {
                    if (c != null && c.moveToFirst()) target = ContentUris.withAppendedId(col, c.getLong(0));
                }
                if (target == null) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    v.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                    v.put(MediaStore.Downloads.RELATIVE_PATH, BACKUP_DIR);
                    target = cr.insert(col, v);
                }
                if (target == null) return "error";
                try (OutputStream out = cr.openOutputStream(target, "wt")) {
                    if (out == null) return "error";
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                }
                return "ok";
            } catch (Exception e) {
                return "error";
            }
        }

        /** List the backups this app saved in Downloads/Daybook, newest first, as JSON. */
        @JavascriptInterface
        public String listBackups() {
            JSONArray arr = new JSONArray();
            if (Build.VERSION.SDK_INT < 29) return arr.toString();
            try (Cursor c = getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME,
                            MediaStore.Downloads.DATE_MODIFIED, MediaStore.Downloads.SIZE},
                    MediaStore.Downloads.RELATIVE_PATH + "=?", new String[]{BACKUP_DIR},
                    MediaStore.Downloads.DATE_MODIFIED + " DESC")) {
                while (c != null && c.moveToNext()) {
                    String name = c.getString(1);
                    if (name == null || !name.toLowerCase().endsWith(".json")) continue;
                    JSONObject o = new JSONObject();
                    o.put("id", String.valueOf(c.getLong(0)));
                    o.put("name", name);
                    o.put("date", c.getLong(2) * 1000L);
                    o.put("size", c.getLong(3));
                    arr.put(o);
                }
            } catch (Exception ignored) { }
            return arr.toString();
        }

        /** Read one of the backups listed above. */
        @JavascriptInterface
        public String readBackup(String id) {
            if (Build.VERSION.SDK_INT < 29) return "";
            try {
                Uri uri = ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, Long.parseLong(id));
                String text = readText(uri);
                return text == null ? "" : text;
            } catch (Exception e) {
                return "";
            }
        }

        /** Open Android's print screen for a report, where "Save as PDF" is available. */
        @JavascriptInterface
        public void printPdf(String html, String name) {
            runOnUiThread(() -> {
                try {
                    printView = new WebView(MainActivity.this);
                    printView.setWebViewClient(new WebViewClient() {
                        private boolean printed = false;

                        @Override
                        public void onPageFinished(WebView view, String url) {
                            if (printed) return;
                            printed = true;
                            PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                            PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(name);
                            pm.print(name, adapter, new PrintAttributes.Builder()
                                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                    .build());
                        }
                    });
                    printView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Couldn't create the PDF: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            });
        }

        /** Match the area behind the phone's status and navigation bars to the app theme. */
        @JavascriptInterface
        public void setBars(String hex, boolean lightTheme) {
            runOnUiThread(() -> {
                try {
                    int c = Color.parseColor(hex);
                    root.setBackgroundColor(c);
                    web.setBackgroundColor(c);
                    WindowInsetsControllerCompat ctl =
                            WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
                    ctl.setAppearanceLightStatusBars(lightTheme);
                    ctl.setAppearanceLightNavigationBars(lightTheme);
                } catch (Exception ignored) { }
            });
        }
    }
}
