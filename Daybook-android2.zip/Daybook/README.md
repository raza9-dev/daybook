# Daybook 3.1 – Android app

Developed by Farzad Raza, Badloon Technology & Academy (0745 616 316).

Daily expenses, income, profit and notes. Works offline; data stays on the phone.
English, Dari and Pashto. Reports (week / month / year) with PDF export, history search, backup & restore, Excel (CSV) export, light/dark theme.

Build: GitHub Actions (`.github/workflows/build-apk.yml`) builds `Daybook.apk` (install on a phone) and `Daybook.aab` (upload to Google Play).
App ID on Google Play: com.badloon.daybook. Targets Android 16 (API 36).
The APK is signed with `app/daybook.keystore`, so every new build installs as an update.
Keep this repository private: the key and its password are in `app/build.gradle`.
